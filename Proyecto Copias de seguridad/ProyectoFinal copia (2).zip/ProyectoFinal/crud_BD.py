import crud_conexion

class crud_BD:
    def __init__(self):
        self.db = crud_conexion.crud()  

    def consultar(self):
        return self.db.consultar("SELECT * FROM publicacion_vehiculos")
    
    def insertar_vehiculo(self, datos):
        sql = """
            INSERT INTO publicacion_vehiculos (nombre_vehiculo, precio, descripcion, imgVehiculo, imgVehiculo2)
            VALUES (%s, %s, %s, %s, %s)
        """
        valores = (datos["nombre_vehiculo"], datos["precio"], datos["descripcion"], datos["imgVehiculo"], datos["imgVehiculo2"])
        return self.db.procesar_consultas(sql, valores)
