import os
import json
from http.server import HTTPServer, SimpleHTTPRequestHandler
from requests_toolbelt.multipart.decoder import MultipartDecoder
import crud_BD

# Inicializar la base de datos
crudBD = crud_BD.crud_BD()

# Asegúrate de que el directorio 'imagenes' exista
if not os.path.exists('imagenes'):
    os.makedirs('imagenes')

class servidorBasico(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.path = '/menuPrincipal.html'
        elif self.path == '/publicaciones':
            self.path = '/publicaciones.html'
        elif self.path == '/get_publicaciones':
            # Enviar datos de publicaciones en formato JSON
            publicaciones = crudBD.consultar()  # Obtener todas las publicaciones
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(publicaciones).encode('utf-8'))
            return
        elif self.path.startswith('/imagenes/'):
            self.path = '.' + self.path  # Servir archivos del directorio 'imagenes'
        elif self.path.startswith('/EllenImagen/'):  # Ruta para las imágenes de la carpeta EllenImagen
            self.path = '.' + self.path  # Servir archivos del directorio EllenImagen
        else:
            self.send_error(404, 'Not Found')
            return
        
        # Llamar al método do_GET del manejador base
        return SimpleHTTPRequestHandler.do_GET(self)

    def do_POST(self):
        content_type = self.headers.get('Content-Type')
        
        if 'multipart/form-data' in content_type:
            # Leer los datos del cuerpo de la solicitud
            content_length = int(self.headers['Content-Length'])
            body = self.rfile.read(content_length)
            
            # Decodificar el formulario multipart
            decoder = MultipartDecoder(body, content_type)
            
            nombre_vehiculo, precio, descripcion, Comentario = None, None, None, None
            img_data1, img_data2 = None, None  # Almacenar datos de ambas imágenes
            
            for part in decoder.parts:
                content_disposition = part.headers.get(b'Content-Disposition').decode()
                field_name = [param.split('=')[1].strip('"') for param in content_disposition.split(';') if 'name=' in param]
                
                if field_name:
                    field_name = field_name[0]
                    if field_name == 'nombre_vehiculo':
                        nombre_vehiculo = part.text
                    elif field_name == 'precio':
                        precio = part.text
                    elif field_name == 'descripcion':
                        descripcion = part.text
                    elif field_name == 'Comentario':
                        Comentario = part.text
                    elif field_name == 'imgVehiculo':
                        img_data1 = part.content
                    elif field_name == 'imgVehiculo2':
                        img_data2 = part.content

            # Validación de campos obligatorios
            if not (nombre_vehiculo and precio and descripcion and img_data1):
                self.send_error(400, 'Faltan datos o imágenes requeridos')
                return

            # Generar nombres únicos para las imágenes
            img_filename1 = f"{nombre_vehiculo.replace(' ', '_')}_1.jpg"
            img_filename2 = f"{nombre_vehiculo.replace(' ', '_')}_2.jpg" if img_data2 else None

            # Guardar las imágenes en el servidor
            with open(os.path.join('imagenes', img_filename1), 'wb') as img_file1:
                img_file1.write(img_data1)

            if img_data2:
                with open(os.path.join('imagenes', img_filename2), 'wb') as img_file2:
                    img_file2.write(img_data2)

            # Insertar el registro en la base de datos (nombre de las imágenes)
            datos = {
                'nombre_vehiculo': nombre_vehiculo,
                'precio': precio,
                'descripcion': descripcion,
                'Comentario': Comentario,
                'imgVehiculo': img_filename1,
                'imgVehiculo2': img_filename2 if img_filename2 else ''
            }
            resp = {"msg": crudBD.insertar_vehiculo(datos)}

            # Responder al cliente
            self.send_response(200)
            self.end_headers()
            self.wfile.write(json.dumps(resp).encode('utf-8'))

        elif self.path == '/agregar_comentario':
            # Leer y procesar los comentarios enviados
            content_length = int(self.headers['Content-Length'])
            post_data = json.loads(self.rfile.read(content_length))
            
            id_publicacion = post_data.get('id_publicacion')
            comentario = post_data.get('comentario')

            # Validar los datos
            if not (id_publicacion and comentario):
                self.send_error(400, 'Faltan datos para el comentario')
                return

            # Intentar actualizar la base de datos con el comentario
            try:
                crudBD.agregar_comentario(id_publicacion, comentario)
            except Exception as e:
                self.send_error(500, f'Error al agregar comentario: {str(e)}')
                return

            # Responder con éxito
            self.send_response(200)
            self.end_headers()
            self.wfile.write(json.dumps({'msg': 'Comentario agregado exitosamente'}).encode('utf-8'))
            
        else:
            self.send_error(400, 'Bad Request')

# Iniciar el servidor
server = HTTPServer(('localhost', 3001), servidorBasico)
print("Servidor ejecutado en el puerto 3001")
server.serve_forever()
