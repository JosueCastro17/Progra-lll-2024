import crud_conexion
db = crud_conexion.crud()

class crud_academico:
    def consultar(self):
        productos = db.consultar("SELECT * FROM usuarios")
        # Convertir los valores de 'precio' de Decimal a float
        for producto in productos:
            producto["precio"] = float(producto["precio"])
        return productos
    
    def administrar(self, datos):    
        sql = """
            INSERT INTO Productos (nombre, producto, precio)
            VALUES (%s, %s, %s) 
        """
        valores = (datos["nombre"],  datos["producto"], datos["precio"])
        return db.procesar_consultas(sql, valores)
    
    def eliminar(self, id):
        sql = "DELETE FROM Productos WHERE id = %s"
        valores = (id,)
        return db.procesar_consultas(sql, valores)
    
    def modificar(self, id, datos):
        sql = """
            UPDATE Productos
            SET nombre = %s, producto = %s, precio = %s
            WHERE id = %s
        """
        valores = (datos["nombre"],  datos["producto"], datos["precio"], id)
        return db.procesar_consultas(sql, valores)